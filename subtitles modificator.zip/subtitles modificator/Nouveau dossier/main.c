#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#ifdef _WIN32
#include <windows.h>
#endif
void lecture(FILE *fichier){
    /*printf("debut de lecture\n");
    char ligne[1000]; 
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        printf("%s", ligne);
    }
    rewind(fichier);
    printf("fin de lecture\n");*/
}
int verificationligne(const char *ligne) {
        if (strstr(ligne, "-->") != NULL) {
            return 1; // La ligne est valide
        }
    return 0; // La ligne n'est pas sous la forme attendue
}
void ajoutdutemp(int *h1, int *m1, int *s1, int *ms1,int *h2,int *m2,int *s2,int *ms2, int secondes){
    (*s1) = (*s1) + secondes;
    if (*ms1 >= 1000) {
        (*s1)++;
        *ms1 -= 1000;
    }

    if (*s1 >= 60) {
        (*m1)++;
        *s1 -= 60;
    }

    if (*m1 >= 60) {
        (*h1)++;
        *m1 -= 60;
    }
        // Ajoute une seconde
    (*s2) = (*s2) + secondes;
    if (*ms2 >= 1000) {
        (*s2)++;
        *ms2 -= 1000;
    }

    if (*s2 >= 60) {
        (*m2)++;
        *s2 -= 60;
    }

    if (*m2 >= 60) {
        (*h2)++;
        *m2 -= 60;
    }
}
void decalage(FILE *fichier, FILE *fichier_temp, int secondes) {
    char ligne[100]; int m1, s1, ms1, m2, s2, ms2; int h1 = 0; int h2 = 0;
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        if (verificationligne(ligne)==1) {
            sscanf(ligne, "%d:%d:%d,%d --> %d:%d:%d,%d",
            &h1, &m1, &s1, &ms1, &h2, &m2, &s2, &ms2);
            ajoutdutemp(&h1, &m1, &s1, &ms1, &h2, &m2, &s2, &ms2, secondes);
            fprintf(fichier_temp, "0%0d:%02d:%02d,%03d --> 0%0d:%02d:%02d,%03d\n",
            h1, m1, s1, ms1, h2, m2, s2, ms2);
        } else {
            fputs(ligne, fichier_temp);
        }
    }
}
int main() {
    char nomFichier[100];
    char cheminComplet[256];
    int secondes;
    // Demander à l'utilisateur de saisir le nom du fichier
    printf("Veuillez saisir le nom du fichier sous titre qui se trouve dans le meme repertoire que le programme.\n Uniquement l'extension .srt : ");
    scanf("%s", nomFichier);
    do {
        printf("Veuillez saisir le nombre de secondes de decalage des sous-titres (positif pour avancer et negatif pour reculer): \n");

        // Vérifie que la saisie est un entier
        if (scanf("%d", &secondes) != 1) {
            // Effacer le tampon d'entrée en cas d'entrée incorrecte
            while (getchar() != '\n');
            printf("La saisie n'est pas un entier valide. Reessayez.\n");
        } else {
            // Sort de la boucle si l'entrée est un entier valide
            break;
        }
    } while (1);
    #ifdef _WIN32
    DWORD pathSize = GetFullPathName(nomFichier, sizeof(cheminComplet), cheminComplet, NULL);
    if (pathSize == 0) {
        // Gestion de l'erreur
        perror("ERREUR : Impossible d'obtenir le chemin complet du fichier\n");
        return 1;
    }
    #endif
    // Vérifier si l'extension est .srt
    char *extension = strrchr(nomFichier, '.');
    if (extension != NULL && strcmp(extension, ".srt") == 0) {
        printf("Le fichier est un fichier .srt\n");
        if(access(nomFichier, F_OK) != -1){//vérifier que le fichier existe
            printf("Le fichier existe\n");
            FILE *fichier = fopen(nomFichier, "r+");
            // Vérifier si le fichier est ouvert avec succès
            if (fichier == NULL) {
                perror("ERREUR Impossible d'ouvrir le fichier\n");
                return 1;
            }
            printf("fichier ouvert avec succes\n");
            const char *suffixe = "new ";
            char nomFichierTemp[100];
            strcpy(nomFichierTemp, suffixe);
            strcat(nomFichierTemp, nomFichier);
            remove(nomFichierTemp);
            FILE *fichier_temp = fopen(nomFichierTemp, "w");
            if (fichier_temp == NULL) {
                perror("ERREUR : Impossible de créer le fichier temporaire");
                return 1;  // Terminer le programme avec un code d'erreur
            }
            printf("fichier temporaire '%s' creer\n", nomFichierTemp);
            decalage(fichier, fichier_temp, secondes);
            printf("fermeture du fichier '%s'\n", nomFichier);
            fclose(fichier);
            printf("fermeture du fichier '%s'\n", nomFichierTemp);
            fclose(fichier_temp);
            printf("\n\n\n-----SUCCES------\n");
            printf("un nouveau fichier de sous titre nomme '%s' a ete creer. celui ci contient vos modifications\n", nomFichierTemp);
        }else{
            printf("ERREUR le fichier n'existe pas. Verifiez le repertoire %s \n",cheminComplet);
        }
    } else {
        printf("ERREUR Le fichier n'est pas un fichier .srt. Traitement non autoriser.\n");
    }
    
    sleep(322);
    return 0;
}